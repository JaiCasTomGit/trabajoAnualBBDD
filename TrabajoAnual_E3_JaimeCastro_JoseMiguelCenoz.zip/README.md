## Bases de Datos 
## Proyecto Anual Segunda Entrega
<img src="portada.jpg">

##### Hecho por Jaime Castro y José Miguel Cenoz, 1ºDAW


## Índice

1. [Descripción del Sistema](#descripción-del-sistema)
2. [Requisitos del Sistema](#requisitos-del-sistema)
    - [Funcionales](#funcionales)
    - [No Funcionales](#no-funcionales)
        - [Estudio SGBD a usar](#estudio-SGBD-a-usar)
        - [Funcionamiento de _BBDD_ distribuida](#funcionamiento-de-_BBDD_-distribuida)
        - [Ubicación de los datos o Almacenamiento Físico](#ubicación-de-los-datos-o-almacenamiento-físico)
        - [Crecimiento](#crecimiento)
        - [Plan de respaldo](#plan-de-respaldo)
3. [Modelo Entidad Relación](#modelo-entidad-relación)
    - [Resumen de modificaciones realizadas](#resumen-de-modificaciones-realizadas)
4. [Modelo Relacional](#modelo-relacional)
5. [Bibliografía](#bibliografía)
<div style="page-break-before: always;"></div>

## Descripción del Sistema
Una compañía de videojuegos ha desarrollado un juego en el que se controla un personaje y tienes que derrotar distintos jefes, ubicados en el mapa del juego. 
Se quiere recoger información del jugador, jefes, ubicaciones del mapa, armas, objetos y enemigos básicos.

## Requisitos del sistema
### Funcionales

- Se debe mantener la integridad referencial entre todas las entidades mediante claves primarias y foráneas, incluyendo herencias y tipos especializados.

1. Gestión de jugadores
- El sistema debe permitir crear, consultar, modificar y eliminar jugadores, cada uno identificado por un código único (codigoJugador).
- Cada jugador debe tener asociada una clase (CLASE) y estadísticas propias basadas en las estadísticas de la clase.
- Cada jugador debe tener su inventario y estadísticas asociadas.
- Los jugadores pueden equipar armas y objetos.

2. Clases y especializaciones
- El sistema debe diferenciar entre las clases Guerrero, Mago y Caballero como tipos especializados de clase.
- Cada clase debe tener estadísticas base (ESTADISTICAS_CLASE) que se utilicen para calcular las estadísticas del jugador.
- Cada jugador puede tener solo una clase activa, aunque la clase puede no tener jugadores asignados.

<div style="page-break-before: always;"></div>

3. Objetos y armas
- El sistema debe permitir crear y gestionar objetos con CodigoObjeto, NombreObjeto y TipoObjeto.
- Cada arma debe estar vinculada a un objeto base y tener atributos como Dano y NivelMejora.
- El sistema debe garantizar que cada arma y objeto en un inventario esté correctamente referenciado y no se duplique indebidamente.
- El sistema debe controlar las copias de armas disponibles en el juego.
- Los jugadores deben poder equipar objetos y armas de su inventario.



4. Estadísticas
- Los jugadores y las clases deben tener estadísticas asociadas.
- Las estadísticas deben reflejar atributos base de la clase o mejoras obtenidas por objetos.
- El sistema debe calcular y actualizar las estadísticas del jugador al equipar objetos o subir de nivel, respetando los valores base de la clase.

5. Enemigos y jefes
- El sistema debe permitir crear enemigos y diferenciarlos en jefes y enemigos básicos.
- El sistema debe permitir crear enemigos (ENEMIGO) que puedan aparecer en mapas y soltar objetos al ser derrotados.
- Algunos enemigos pueden ser jefes (JEFE), y cada jefe es un enemigo único por mapa.
- El sistema debe diferenciar enemigos básicos (ENMBASICO) de jefes, manteniendo la relación jerárquica con la tabla de enemigos.
- Las relaciones jerárquicas y de especialización entre clases, enemigos y jefes deben estar reflejadas y respetadas en todas las operaciones del sistema.
- Los jugadores deben poder enfrentarse ante enemigos presentes en los mapas.

6. Mapas
- Cada mapa debe tener un inventario asociado con botín específico que los jugadores pueden recoger.
- Cada mapa debe contener un inventario y enemigos.
- Cada jefe es único por mapa.
- El sistema debe poder listar enemigos y jefes que aparecen en un mapa determinado.

<div style="page-break-before: always;"></div>

7. Inventario
- Los jugadores deben poder tener inventarios de tipo “jugador” y acceder al botín de los mapas a través de inventarios de tipo “mapa”.
- Cada inventario debe contener objetos (OBJETO) y armas (ARMA), y cada arma puede depender de múltiples copias (COPIAS_ARMAS).
- Se debe permitir consultar el contenido de cualquier inventario, diferenciando entre inventario de jugador e inventario de mapa.
- Debe permitir almacenar objetos y armas.
- Debe reflejar qué objetos y armas están actualmente equipados por el jugador.


### No funcionales
Se ha seleccionado para esta tarea, una base de datos relacional, ya que los datos de un videojuego, mantienen una relación natural entre entidades participantes del medio.

Se hacen referencias constantes entre tablas, por ejemplo transacciones o reglas (enemigo no deja arma si no es eliminado por jugador, por ejemplo). 

Usando el modelo relacional es posible conseguir diseño, integridad y consultas. Siendo estas últimas un método eficiente para recuperar información sobre la experiencia, por ejemplo si hay zonas demasiado diİciles, comparando las veces que el jugador ha sido eliminado en una zona concreta, cuáles son las armas mas usadas etc.

<div style="page-break-before: always;"></div>

#### Estudio _SGBD_ a usar
Hay varias opciones a la hora de seleccionar el _SGBD_ que más nos convene para este sistema de información. Entre ellos hemos seleccionado `MySQL`, `SQLite`, `PostgreSQL` y `Oracle`.
- **`MySQL`**: gran facilidad de uso y rednimiento. Tiene soporte multiplataforma, lo que permite trabajar con los archivos del juego fácilmente, y mantiene la comunicación segura entre navegador y servidor mediante su soporte `SSL`. El mayor problema es que no es escalable, por lo que si se quieren realizar cambios, podría no ser la mejor opción.

- **`SQLite`** nos permite guardar toda esta información fácilmente, aunque su tamaño sea mucho menor que cualquier otro al tratarse de una biblioteca, su gran portabilidad y rendimiento nos permite usar este sistema para trabajar con la _BBDD_.

- **`PostgreSQL`**: gran capacidad de uso multiplataforma y herramientas que permiten administrar fácilmente la _BBDD_. Este _SGBD_ es robusto y eficaz, pero al mismo tiempo, nos permite realizar una configuración compatible con _BBDD_ más pequeñas. También, al ser un sistema que permite el uso multiplataforma, podemos manejar `JSON` o `CTE`,(prominentes en el desarrollo de videojuegos), cosa especialmente útil, cuando se trata de sistemas de inventario.

- **`Oracle`**, por otro lado, es más completo. Por lo que sería perfecto si se tratara de una base de datos que estuviera en constante evolución, ya que tiene una gran escalabilidad. Sin embargo, éste no es el caso, por lo que no es el _SGBD_ que más nos conviene, aunque tenga buenas características para uso empresarial.

En conclusión, por todo lo anteriormente descrito, nos decantamos por usar el _SGBD_ de **`PostgreSQL`**; por su capacidad de personalización, manejo de `JSON/CTE`, gran uso multiplataforma etc.

#### Funcionamiento de BBDD distribuida
Esta _BBDD_  funcionaría en una distribuida, aunque no tendría sentido más allá de la seguridad de la información, ya que la _BBDD_ se ejecutaría en la máquina personal del jugador. Sin embargo, si se tratará de un juego en línea, dónde las actualizaciones son constantes, podría ser preferible, para que la máquina del jugador no tenga que ejecutar dicha _BBDD_, puesto que pueden llegar a alcanzar tamaños enormes.

<div style="page-break-before: always;"></div>

#### Ubicación de los datos o Almacenamiento Físico
La empresa tendría un servidor central para ubicar la base de datos principal del juego, en el que se guardarían absolutamente todos los datos de la misma. Cada jugador tendría su propia copia del mismo, pero con los datos actualizados de su partida. 
Si se hiciera alguna actualización del juego, sería mediante un _script_ de migración, que en resumen es un _script_ _SQL_ que sirve para hacer cambios en una base de datos de forma segura (en el transcurso de actualizaciones). 
Esto se haría en caso de que se añada o elimine algún arma del juego, o para contenido extra del juego.
Cabe mencionar que se puede dar el caso de que haya un riesgo de incompatibilidad de versión, si un jugador no actualiza el juego cuando se distribuya una actualización, su _BBDD_ quedaría desactualizada, por lo que los datos podrían no coincidir con la versión que se publica, o parche actual de la empresa.

#### Crecimiento
No se prevé un gran crecimiento de esta base de datos, sin embargo, si la compañía desea hacer actualizaciones o ampliaciones de contenido (como contenido descargable, o una continuación del mismo). Se podría usar esta _BBDD_ de plantilla.

#### Plan de respaldo
Al tratarse de una base de datos pequeña y que se actualiza poco, no es necesario un plan de respaldo especialmente complejo (solamente que el jugador guarde su partida antes de salir del juego). Sin embargo, también se podría plantear, que la empresa distribuidora del juego permitiera autoguardados en la nube de las partidas de los distintos jugadores, por lo que si un jugador pierde su partida, o esta se corrompe pueda recuperarla fácilmente.

<div style="page-break-before: always;"></div>

## Modelo Entidad Relación

```mermaid
erDiagram

    %% ENTIDADES
    JUGADOR {
        int codigoJugador PK
        string nombre
        int nivel
        int codigoClase FK
    }

    CLASE {
        int codigoClase PK
        string nomClase
    }

    CLASE_GUERRERO {
        int codigoClase PK, FK
    }

    CLASE_MAGO {
        int codigoClase PK, FK
    }

    CLASE_CABALLERO {
        int codigoClase PK, FK
    }

    ESTADISTICAS_CLASE {
        int codigoClase PK, FK
        int fuerza_base
        int destreza_base
        int arcano_base
        int agilidad_base
        int salud_base
    }

    EST_JUGADOR {
        int codigoJugador PK, FK
        int fuerza
        int destreza
        int arcano
        int agilidad
        int salud
        int puntos_disponibles
    }

    INVENTARIO {
        int codigoInventario PK
        string tipoInventario 
        int codigoJugador FK 
        int codigoMapa FK 
    }

    OBJETO {
        int codObjeto PK
        int codigoInventario FK
        string nomObjeto
        string tipoObjeto
    }

    ARMA {
        int codigoArma PK
        int codigoInventario FK
        int codigoObjeto FK
        int dano
    }

    COPIAS_ARMAS {
        int codigoArma PK, FK
        int numCopias
    }

    ENEMIGO {
        int codigoEnemigo PK
    }

    ENMBASICO {
        int codigoEnemigoBas PK
        int codigoEnemigo FK
    }

    JEFE {
        int codigoJefe PK
        int codigoEnemigo FK
    }

    MAPA {
        int codigoMapa PK
    }

    %% RELACIONES

    JUGADOR ||--|| EST_JUGADOR : tiene
    ESTADISTICAS_CLASE ||--|| EST_JUGADOR : basado_en

    JUGADOR ||--|| INVENTARIO : posee
    MAPA ||--|| INVENTARIO : tiene

    INVENTARIO ||--|| OBJETO : contiene
    INVENTARIO ||--|| ARMA : contiene

    JUGADOR ||--o{ ARMA : puede_equipar
    JUGADOR ||--o{ OBJETO : puede_equipar

    COPIAS_ARMAS }|--|| ARMA : depende_de

    CLASE ||--|| ESTADISTICAS_CLASE : tiene
    CLASE ||--|| CLASE_GUERRERO : es_tipo_de
    CLASE ||--|| CLASE_MAGO : es_tipo_de
    CLASE ||--|| CLASE_CABALLERO : es_tipo_de
    CLASE ||--|| ARMA : tiene
    JUGADOR ||--|| CLASE : elige

    ENEMIGO }|--|{ MAPA : aparece_en
    ENEMIGO }o--o{ OBJETO : suelta

    ENEMIGO ||--|| JEFE : es_tipo_de
    ENEMIGO ||--|| ENMBASICO : es_tipo_de

    JEFE ||--|| MAPA : es_unico_por
    JUGADOR ||--|{ ENEMIGO : enfrenta


    
```
```mermaid
erDiagram

    %% =========================
    %% ENTIDADES PRINCIPALES
    %% =========================

    JUGADOR {
        int codigoJugador PK
        string nombre
        int nivel
        int codigoClase FK
    }

    CLASE {
        int codigoClase PK
        string nomClase
    }

    %% Especialización de CLASE
    CLASE_GUERRERO {
        int codigoClase PK, FK
    }

    CLASE_MAGO {
        int codigoClase PK, FK
    }

    CLASE_CABALLERO {
        int codigoClase PK, FK
    }

    ESTADISTICAS_CLASE {
        int codigoClase PK, FK
        int fuerza_base
        int destreza_base
        int arcano_base
        int agilidad_base
        int salud_base
    }

    EST_JUGADOR {
        int codigoJugador PK, FK
        int fuerza
        int destreza
        int arcano
        int agilidad
        int salud
        int puntos_disponibles
    }

    MAPA {
        int codigoMapa PK
    }

    %% =========================
    %% INVENTARIO (contenedor)
    %% =========================

    INVENTARIO {
        int codigoInventario PK
        string tipoInventario
        int codigoJugador FK
        int codigoMapa FK
        %% NOTA: Restricción XOR (Jugador O Mapa)
    }

    %% =========================
    %% ITEM (especialización total y disjunta)
    %% =========================

    ITEM {
        int codItem PK
        int codigoInventario FK
        string nombre
        string tipoItem
    }

    ARMA {
        int codItem PK, FK
        int dano
    }

    OBJETO_USABLE {
        int codItem PK, FK
        string efecto
    }

    COPIAS_ARMAS {
        int codItem PK, FK
        int numCopias
    }

    %% =========================
    %% ENEMIGOS (especialización total y disjunta)
    %% =========================

    ENEMIGO {
        int codigoEnemigo PK
        string nombre
    }

    JEFE {
        int codigoEnemigo PK, FK
    }

    ENMBASICO {
        int codigoEnemigo PK, FK
    }

    %% =========================
    %% ENTIDADES INTERMEDIAS (N:M)
    %% =========================

    ENEMIGO_MAPA {
        int codigoEnemigo PK, FK
        int codigoMapa PK, FK
    }

    DROP_ENEMIGO_ITEM {
        int codigoEnemigo PK, FK
        int codItem PK, FK
    }

    %% =========================
    %% RELACIONES
    %% =========================

    JUGADOR ||--|| EST_JUGADOR : tiene

    CLASE ||--o{ JUGADOR : es_elegida_por
    CLASE ||--|| ESTADISTICAS_CLASE : tiene

    CLASE ||--|| CLASE_GUERRERO : es_tipo_de
    CLASE ||--|| CLASE_MAGO : es_tipo_de
    CLASE ||--|| CLASE_CABALLERO : es_tipo_de

    JUGADOR ||--|| INVENTARIO : posee
    MAPA ||--|| INVENTARIO : contiene

    INVENTARIO ||--o{ ITEM : guarda

    ITEM ||--|| ARMA : es_tipo_de
    ITEM ||--|| OBJETO_USABLE : es_tipo_de

    ARMA ||--o| COPIAS_ARMAS : puede_tener

    ENEMIGO ||--|| JEFE : es_tipo_de
    ENEMIGO ||--|| ENMBASICO : es_tipo_de

    ENEMIGO ||--o{ ENEMIGO_MAPA : aparece
    MAPA ||--o{ ENEMIGO_MAPA : contiene

    ENEMIGO ||--o{ DROP_ENEMIGO_ITEM : suelta
    ITEM ||--o{ DROP_ENEMIGO_ITEM : puede_caer

    JUGADOR ||--o{ ENEMIGO : enfrenta
```
### Resumen de modificaciones realizadas

#### 1. Creación de ITEM como entidad intermedia
- Se introduce `ITEM` como entidad base del sistema de inventario  
- INVENTARIO pasa a contener ITEM y no directamente ARMA u OBJETO_USABLE  
- Se evita redundancia estructural entre tipos de objetos  

#### 2. Especialización total y exclusiva de ITEM
- Todo ITEM debe ser obligatoriamente:
  - ARMA  
  - OBJETO_USABLE  
- No puede existir un ITEM genérico sin subtipo  
- Se aplica restricción conceptual XOR (disyunta y total)

#### 3. ARMA pasa a ser especialización real
- PK compartida (`codItem`)  
- Se elimina cualquier clave artificial propia  
- Hereda identidad directamente de ITEM  

#### 4. OBJETO_USABLE pasa a ser especialización real
- PK compartida (`codItem`)  
- Hereda identidad directamente de ITEM  

#### 5. COPIAS_ARMAS
- Se mantiene como entidad independiente  
- Depende de ARMA mediante PK compartida (`codItem`)  
- Permite modelar número de copias sin duplicar armas  

#### 6. ENEMIGO
- Se añade el atributo `nombre`  
- Mejora la coherencia semántica del modelo  

#### 7. JEFE y ENMBASICO
- Se mantienen como especializaciones reales  
- PK compartida con ENEMIGO  
- Especialización disyunta  

#### 8. Relación de drop corregida
- Se elimina relación directa ENEMIGO ↔ ITEM  
- Se introduce entidad asociativa `DROP_ENEMIGO_ITEM`  
- Se modela correctamente la relación N:M  

#### 9. Restricción conceptual mantenida
- Se mantiene restricción XOR en INVENTARIO  
  (Pertenece a jugador **o** a mapa)

---

Con esto el modelo queda consistente en especialización, normalización y control de restricciones estructurales.

<div style="page-break-before: always;"></div>

## Modelo Relacional
| JUGADOR | |
|--------------|------------|
| codigoJugador | PK |
| nombre        |    |
| nivel         |    |
| codigoClase   | FK |

| CLASE | |
|--------------|------------|
| codigoClase | PK |
| nomClase    |    |

| CLASE_GUERRERO | |
|--------------|------------|
| codigoClase | PK, FK |

| CLASE_MAGO | |
|--------------|------------|
| codigoClase | PK, FK |

| CLASE_CABALLERO | |
|--------------|------------|
| codigoClase | PK, FK |

| ESTADISTICAS_CLASE | |
|--------------|------------|
| codigoClase   | PK, FK |
| fuerza_base   |    |
| destreza_base |    |
| arcano_base   |    |
| agilidad_base |    |
| salud_base    |    |

| EST_JUGADOR | |
|--------------|------------|
| codigoJugador | PK, FK |
| fuerza        |    |
| destreza      |    |
| arcano        |    |
| agilidad      |    |
| salud         |    |
| puntos_disponibles |    |

| INVENTARIO | |
|--------------|------------|
| codigoInventario | PK |
| tipoInventario   |    |
| codigoJugador    | FK |
| codigoMapa       | FK |

| ITEM | |
|--------------|------------|
| codItem          | PK |
| codigoInventario | FK |
| nomItem          |    |
| tipoItem         |    |

| ARMA | |
|--------------|------------|
| codItem       | PK, FK |
| dano          |    |

| OBJETO_USABLE | |
|--------------|------------|
| codItem       | PK, FK |
| descripcion   |    |

| COPIAS_ARMAS | |
|--------------|------------|
| codItem       | PK, FK |
| numCopias     |    |

| ENEMIGO | |
|--------------|------------|
| codigoEnemigo | PK |
| nombre        |    |

| ENMBASICO | |
|--------------|------------|
| codigoEnemigo | PK, FK |

| JEFE | |
|--------------|------------|
| codigoEnemigo | PK, FK |

| DROP_ENEMIGO_ITEM | |
|--------------|------------|
| codigoEnemigo | PK, FK |
| codItem       | PK, FK |
| cantidadMin   |    |
| cantidadMax   |    |
| probabilidad  |    |

| MAPA | |
|--------------|------------|
| codigoMapa | PK |

---

### Notas sobre el modelo relacional

1. `ITEM` es la entidad base que contiene `ARMA` y `OBJETO_USABLE` como especializaciones reales (PK compartida).  
2. `COPIAS_ARMAS` depende de `ARMA` mediante PK compartida (`codItem`).  
3. `DROP_ENEMIGO_ITEM` materializa la relación N:M entre `ENEMIGO` y `ITEM`, permitiendo atributos adicionales como probabilidad o cantidad.  
4. `INVENTARIO` contiene `ITEM` y mantiene restricción XOR: pertenece a un jugador **o** a un mapa.  
5. No existen relaciones directas redundantes entre `JUGADOR ↔ ITEM/ARMA/OBJETO_USABLE`.
<div style="page-break-before: always;"></div>

## Bibliografía
Parte de la información que hemos expuesto está en internet y otra en los apuntes de
clase, las fuentes son las siguientes:

- https://www.red-gate.com/blog/a-database-model-for-action-games?.com

- https://learn.microsoft.com/en-us/sql/relational-databases/databases/estimate-the-size-of-a-database?view=sql-server-ver17

- http://Postgresql.org

- https://docs.aws.amazon.com/wellarchitected/latest/games-industry-lens/games-scenario-4.html?.com

- https://knowledgebase.apexsql.com/migration-scripts-introduction-and-general-review/?_x_tr_sl&_x_tr_tl&_x_tr_hl

También dejamos acceso a información sobre el juego en el que nos hemos basado para contrastar información sobre el trabajo que estamos realizando.
- https://darksouls.fandom.com/es/wiki/Dark_Souls_III 
